#pragma once
#pragma warning(disable: 4996)
#include <iostream>
#include <Windows.h>
#include "Console.h"
#include <time.h>
#include <string.h>
#include <strsafe.h>