#pragma once

#include "stdafx.h"
#include "CBaseObject.h"

class CObjectManager
{

};
